# Дизайн-токены Вертушки (для макета «Радар»)

Извлечено из `source/theme.ts`. Используй эти значения 1:1, чтобы макет лёг в текущий бренд.

## Палитра (светлый мир — chrome вишлиста)
| Токен | HEX | Роль |
|---|---|---|
| royalBlue | `#3B4BF5` | основной акцент (радар-кнопка, линии) |
| electricBlue | `#5B6AF5` | вторичный синий |
| periwinkle | `#8B9CF7` | светлый акцент |
| lavender | `#C5B8F2` | градиент-хвост |
| softPink | `#F0C4D8` | розовый (заголовок КОЛЛЕКЦИЯ) |
| deepNavy | `#0A0B3B` | текст/тёмный |
| background | `#FAFBFF` | фон экрана (голубоватый белый) |
| surface | `#F0F2FA` | карточки/кнопки-контролы |
| surfaceHover | `#E8EBFA` | ховер |
| text | `#0A0B3B` | основной текст |
| textSecondary | `#5A5F8A` | вторичный |
| textMuted | `#9A9EBF` | приглушённый (нет в наличии) |
| success | `#30A46C` | зона покупки (зелёная) |
| error | `#E5484D` | — |
| border | `#E0E3F0` | границы, пунктир дна графика |
| divider | `#ECEEF7` | разделители |
| cardShadow | `rgba(59,75,245,0.08)` | синяя мягкая тень |
| glassBg | `rgba(250,251,255,0.85)` | стеклянный action-bar |

## Тёмный мир — поверхность РАДАРА (уже есть в приложении: MarketPalette)
Радар-вью строй на этом «тёмном мире», он нативный для приложения (раздел Маркет).
| Токен | HEX | Роль |
|---|---|---|
| void | `#0E0726` | тёмный верх-лево |
| darkVoid | `#0A0218` | signature тень (центр-верх) |
| indigo | `#241057` | глубокий индиго (базовый фон радара) |
| violet | `#5E2099` | насыщенный фиолет (glow) |
| cobalt | `#2D4FDB` | бренд-мост, кольца/sweep |
| azure | `#5780F0` | голубой акцент |
| peach | `#F4A06A` | тёплый акцент (редкий, для «горячих» хитов) |
| chrome.border | `rgba(255,255,255,0.18)` | границы стеклянных элементов на тёмном |
| chrome.fill | `rgba(255,255,255,0.06)` | заливка стекла |
| chrome.textPrimary | `#FFFFFF` | текст на тёмном |
| chrome.textSecondary | `rgba(255,255,255,0.70)` | вторичный на тёмном |

**Рекоменд. фон радара:** radial-градиент `#0A0218` (центр-тень) → `#241057` (indigo) → `#0E0726` (void к краям). Кольца — `cobalt #2D4FDB` @ 12–25% opacity. Sweep-сектор — линейный `royalBlue #3B4BF5` → transparent.

## Spacing
`xs 4 · sm 8 · md 16 · lg 24 · xl 32 · xxl 48`

## BorderRadius
`sm 10 · md 14 · lg 18 · xl 26 · full 9999`

## Gradients
- blue: `#3B4BF5 → #5B6AF5`
- bluePink: `#3B4BF5 → #8B9CF7 → #F0C4D8`
- brand (navy→cobalt→peri): `#0E1A52 → #2A4BD7 → #5C7AE8`
- hotStock (редкий «огонь»): `#0E1A52 → #2A4BD7 → #E85A2A`

## Typography (шрифты приложения)
| Стиль | size/line | шрифт |
|---|---|---|
| heroTitle | 40/44, ls −0.5 | **RubikMonoOne-Regular** (заголовки типа «КОЛЛЕКЦИЯ») |
| display | 32/36 | Inter_800ExtraBold |
| h1 | 26/30 | Inter_700Bold |
| h2 | 20/26 | Inter_700Bold |
| h3 | 17/22 | Inter_600SemiBold |
| body | 16/24 | Inter_400Regular |
| bodyBold | 16/24 | Inter_600SemiBold |
| bodySmall | 14/20 | Inter_400Regular |
| button | 16/20, ls 0.3 | Inter_600SemiBold |
| caption | 12–13 | Inter (muted) |

Числа — tabular. Заголовок «Радар» = heroTitle или display. Подписи внутри радара — bodySmall/caption на белом с альфой.

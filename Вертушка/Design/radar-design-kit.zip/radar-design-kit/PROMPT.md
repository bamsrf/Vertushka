# Design brief — "Радар" (price-watch feature for a vinyl app)

Feed this whole file to the code-design tool together with `design-tokens.md` and the
`source/` component files. Match the existing app's look exactly — read `source/theme.ts`
(tokens), `source/collection.tsx` (wishlist screen you're extending), `source/RecordCard.tsx`
(album-cover card style), `source/PriceSparkline.tsx` (the price chart you must reuse),
`source/record-detail.tsx` (current bell toggle being replaced), `source/NotificationItem.tsx`
(existing wishlist notification texts/icons).

## Concept
A vinyl-collecting iOS app (React Native / Expo, Russian UI). Users add records to a wishlist
and "put them on the radar" to track price. "Radar" is the metaphor: the app scans the market
for you. This replaces a plain bell toggle. Deliver a Figma-style mockup, iPhone ~390×844pt.

Use the BRAND PALETTE and TYPOGRAPHY from `design-tokens.md` exactly (royalBlue #3B4BF5 accent;
RubikMonoOne for hero titles; Inter for the rest; radar surface on the app's dark "MarketPalette"
world — indigo/void/cobalt).

## Locked product decisions
- **Radar radius = price proximity to the user's threshold.** Center = "buy zone": current
  price ≤ user's threshold. The farther a record's price is above threshold, the farther it
  sits from center. This is the core semantic — make it legible.
- **Scope = only "subscribed" records** (ones the user explicitly put on the radar). Not the
  whole wishlist.
- **Entry button pulses continuously** (sonar rings), attention-grabbing.
- **Radar is a full VIEW** (its own screen, push transition) — NOT an overlay.
- **Overlay only on tapping a record** inside the radar → bottom sheet with price history.

## SCREEN 1 — Wishlist with the Radar entry button (light chrome)
Reproduce the real wishlist screen from `source/collection.tsx` (render ~lines 840–925):
- Big pink→lavender hero title "КОЛЛЕКЦИЯ" (RubikMonoOne) + user avatar top-right.
- Segmented toggle "В наличии / Вишлист" (Вишлист active).
- Control row: pill "Выбрать", then round icon buttons — grid/list view, filter
  (options-outline), sort (swap-vertical). All these are light `surface #F0F2FA` circles with
  royalBlue icons.
- **ADD the RADAR button as the RIGHTMOST control in that row.** It must stand out: filled
  royalBlue circle (white radar-sweep icon), while the others are light. It PULSES: draw 2
  concentric royalBlue sonar rings expanding around it (40% and 15% opacity). Small numeric
  badge top-right (e.g. "3") = records that just entered the buy-zone / dropped in price.
- Below: the existing wishlist album grid (from the real screen), slightly dimmed to draw the
  eye to the radar button.

## SCREEN 2 — Radar view (dark "MarketPalette" world, full screen)
- Background: radial `#0A0218 → #241057 (indigo) → #0E0726 (void)`. Faint grain ok.
- Radar rig: 4–5 concentric rings centered mid-screen, cobalt `#2D4FDB` strokes fading outward.
- Sweep: a rotating sector/wedge (~60° wide) filled royalBlue→transparent gradient, brightest
  at leading edge; show it around the 1–2 o'clock position.
- **Center = user's circular AVATAR**, royalBlue ring, softly pulsing.
- **Tracked records = circular album-cover thumbnails** on the radar. Position by the radius
  rule above. Show 5–6 covers (vinyl placeholders): 1–2 inside a central "buy zone" (soft green
  `#30A46C` glow ring around them), the rest spread across outer rings.
- Cover state by ring color: GREEN `#30A46C` = at/below threshold ("бери"); royalBlue = watching;
  dim grey `#9A9EBF` + reduced opacity = not currently in stock.
- If a subscribed record has NO threshold set → park it on the outermost ring (neutral "watching,
  no price target").
- Header: back chevron + title "Радар" + subtitle "Следим за 6 пластинками". A faint caption
  near center: "сканирую цены…".
- Empty state (separate artboard): radar with only the avatar + hint "Поставь пластинку на радар"
  + CTA.

## SCREEN 3 — Record price-history sheet (overlay on cover tap, over Screen 2)
- Bottom sheet ~70% height, light `surface #F0F2FA`, rounded top, dark radar dimmed behind.
- Album cover + title + artist. Row: current price (bold), a "порог" chip (e.g. "дешевле 4000 ₽"),
  status pill (green "В зоне покупки" or blue "Следим").
- **PRICE-DYNAMICS SPARKLINE — reuse `source/PriceSparkline.tsx` verbatim in style:** line chart of
  daily min price over ~90 days (green line if trending down), caption "сейчас N ₽ · мин M ₽",
  dashed floor line at the historical low.
- "История" list: a few rows of past events with dates ("12 июл · 4 490 ₽", "3 июл · появилась в
  продаже", "28 июн · 5 200 ₽").
- Buttons: primary royalBlue "Открыть в магазине"; secondary "Изменить порог".

## SCREEN 4 — Record detail: radar toggle + threshold menu (replaces the bell)
Base = the real record screen `source/record-detail.tsx`. The bottom action bar currently has
three controls: primary "Добавить" | a small bell button | "Удалить". **Replace the bell with
the radar icon** (`icons/radar.svg`). States:
- Not watching → `icons/radar-off.svg` (grey) on light `surface` circle.
- Watching → `icons/radar-white.svg` on a filled royalBlue circle. A tiny white dot badge if a
  threshold is set.

**Interaction (annotate):** tapping the radar icon fires a **single** sonar pulse — ONE ring
ripples out from the icon and fades (not the infinite loop of the wishlist button) — then the
threshold menu slides up. Tapping radar = "put on radar" + opens the menu in one gesture.

**Threshold menu — a custom, polished bottom sheet that REPLACES the ugly native iOS
`Alert.prompt`** (the current one is a plain grey system dialog — see the app's current
threshold prompt; we want something on-brand and beautiful):
- Rounded bottom sheet, light `surface #F0F2FA`, grab-handle at top, dark scrim behind.
- Title "Порог цены" (h2), subtitle "Пуш, когда цена опустится ниже" (textSecondary).
- **Big editable amount**, centered, tabular numerals, with a ₽ suffix — e.g. "4 000 ₽" in
  royalBlue, large (display/h1). Tapping it brings a numeric keypad, but the amount lives inside
  the styled sheet, not a raw system input.
- **Quick presets** as chips under the amount, computed from the current price: "−10%", "−20%",
  round numbers (e.g. "3 500", "3 000"). Selecting a chip fills the amount. Active chip = filled
  royalBlue.
- Context line: current price + a subtle anchor "мин. за 90 дней: M ₽" (from price-history),
  so the user sets a sensible target.
- Optional tiny toggle row "Следить" (on radar) — on by default when opened via the radar tap.
- Buttons: primary royalBlue "Сохранить"; ghost/destructive "Убрать порог" (only if one is set).
- Feel: soft spring-in, tactile, generous spacing. This is the moment that must look nicer than
  the current grey system prompt.

## ICON — the radar (replaces the bell everywhere)
**Must match the reference `screenshots/radar_icon.jpeg` exactly** (b/w radar): a full outer ring,
one prominent inner ring, a LARGE solid center dot, and a symmetric SOLID wedge pointing straight
UP from the center to the top of the outer ring (not diagonal, not translucent). Use the provided
`icons/radar.svg` — it already encodes this geometry (outer r10, inner r6, center dot r2.8, upward
wedge ±27°). Provide at 16/20/24pt, royalBlue and white variants (`radar.svg`, `radar-white.svg`).
`icons/radar-off.svg` (grey, rings + dot, NO wedge) = the "not watching" state replacing bell-slash.

## MOTION (annotate on the static mockup)
- Wishlist radar BUTTON: **infinite** sonar pulse (rings scale 1→2.2, opacity 0.4→0, ~2s) — it
  advertises the radar view continuously.
- Record-detail radar ICON: **single** sonar ripple on tap (one ring, 1→2.2, ~0.5s, fires once),
  then the threshold menu springs up. Not a loop.
- Sweep: 360° rotate ~4s linear; covers it passes over briefly brighten.
- Covers spring toward/away from center as price changes; annotate one with a motion arrow.
- Buy-zone covers: gentle green pulse.
- (Production note, not mockup: respect iOS Reduce Motion; pause pulse when screen unfocused.)

## Deliverables
Artboards:
1. Wishlist + radar entry button (light, continuous pulse).
2. Radar view (dark, avatar center, covers by price-proximity).
3. Radar empty state.
4. Record price-history sheet (PriceSparkline + events).
5. Record detail with radar icon in the action bar (replaces bell) + single-pulse note.
6. **Threshold menu** — the polished custom bottom sheet that replaces the native grey prompt.
Plus the radar icon component (16/20/24pt, royalBlue + white + grey-off).
Premium, calm, tactile — delight moments, not a busy dashboard.

---

## AUTHORITATIVE UPDATES (override anything above where it conflicts; full copy in `WORDING.md`)

### Radar statuses — FOUR now, outline chips
Rename + add one. Legend at bottom, outline (contour) chips:
- 🟢 `#30A46C` **подходит** — in stock AND price ≤ threshold (for the chosen conditions).
- 🔵 `#3B4BF5` **в продаже** — in stock, but above threshold or no threshold set.
- 🟠 `#F4A06A` (peach) **альтернатива** — a DIFFERENT version (same album/master) is in stock.
- ⚪ `#9A9EBF` **отсутствует** — not in stock yet, still tracked.

### Price chips on circles
Show the LOWEST price that qualifies (respecting the chosen condition filter) as a small chip
under the cover — for GREEN, BLUE and ALT circles. Grey (отсутствует) shows no price.
No persistent titles; the item name briefly appears as the sweep beam passes over it.

### New micro-flow — tapping an "альтернатива" (peach) circle
Opens a small confirm sheet:
- Title «Другая версия в наличии»
- Body «В продаже другой прессинг этого альбома. Считать его подходящим?»
- Buttons «Да, следить» / «Нет». On "Да" the alt becomes a tracked match (turns blue/green).
Add this as an artboard.

### Threshold menu — NO system keyboard, NO watch-toggle, ADD condition filter
- The amount is a DISPLAY, not a text field. It changes via: preset chips (−10% / −20% / round
  numbers) + a slider (historical-low → current price) + ±100/±500 steppers. The iOS keyboard
  must NEVER appear (it would cover the sheet). Design the value control to live fully inside the
  sheet.
- REMOVE the "Следить на радаре" toggle entirely — setting a threshold already means "on radar".
- ADD a **"Состояние"** section: multi-select checkboxes for acceptable media condition (vinyl
  grading canon): ☑ Запечатана · ☑ Идеальная (M/NM) · ☐ Отличная (VG+) · ☐ Хорошая (VG), plus an
  optional "Любое состояние" that checks all. This set filters which listings count toward the
  "lowest matching price" and the green buy-zone. (Data exists: listings carry a `condition`.)
- Buttons: «Сохранить» + link «Убрать порог».

### Shorter labels
- History sheet buttons: «В магазин» (primary) / «Порог» (secondary, radar icon).
- Status pills on the history sheet mirror the legend: green «Подходит» / blue «В продаже» /
  peach «Альтернатива».

### Empty state copy
- Title «Поставь пластинку на радар»
- Body «Задай желаемую цену — будем следить и сообщим, как только пластинка появится в продаже и
  подешевеет до неё.»
- CTA «Открыть вишлист»

### Extra artboards from these updates
- Alt-confirm sheet.
- Threshold menu WITH the «Состояние» checklist visible.
